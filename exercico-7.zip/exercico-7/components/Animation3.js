import React, { useEffect, useRef } from 'react';
import { Animated, View, StyleSheet } from 'react-native';

export default function Animation3() {
  const anims = [
    useRef(new Animated.Value(0)).current,
    useRef(new Animated.Value(0)).current,
    useRef(new Animated.Value(0)).current,
  ];

  useEffect(() => {
    Animated.stagger(100, [
      Animated.spring(anims[0], {
        toValue: 1,
        friction: 3,
        useNativeDriver: true,
      }),
      Animated.spring(anims[1], {
        toValue: 1,
        friction: 3,
        useNativeDriver: true,
      }),
      Animated.spring(anims[2], {
        toValue: 1,
        friction: 3,
        useNativeDriver: true,
      }),
    ]).start(() => {
      Animated.stagger(100, [
        Animated.spring(anims[0], {
          toValue: 0,
          friction: 3,
          useNativeDriver: true,
        }),
        Animated.spring(anims[1], {
          toValue: 0,
          friction: 3,
          useNativeDriver: true,
        }),
        Animated.spring(anims[2], {
          toValue: 0,
          friction: 3,
          useNativeDriver: true,
        }),
      ]).start();
    });
  }, []);

  return (
    <View style={styles.container}>
      {anims.map((anim, index) => (
        <Animated.View 
          key={index}
          style={[styles.circle, {
            transform: [{ 
              translateY: anim.interpolate({
                inputRange: [0, 1],
                outputRange: [0, -20 * (index + 1)],
              }) 
            }],
            backgroundColor: '#FFD166',
          }]} 
        />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
  },
  circle: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginVertical: 5,
  },
});