import React, { useEffect, useRef } from 'react';
import { Animated, View, StyleSheet } from 'react-native';

export default function Animation2() {
  const anim1 = useRef(new Animated.Value(0)).current;
  const anim2 = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(anim1, {
        toValue: 1,
        duration: 500,
        useNativeDriver: true,
      }),
      Animated.timing(anim2, {
        toValue: 1,
        duration: 500,
        delay: 200,
        useNativeDriver: true,
      }),
    ]).start(() => {
      Animated.parallel([
        Animated.timing(anim1, {
          toValue: 0,
          duration: 500,
          delay: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(anim2, {
          toValue: 0,
          duration: 500,
          delay: 1000,
          useNativeDriver: true,
        }),
      ]).start();
    });
  }, []);

  return (
    <View style={styles.container}>
      <Animated.View style={[styles.circle, {
        transform: [{ translateX: anim1.interpolate({
          inputRange: [0, 1],
          outputRange: [0, -50],
        }) }],
        backgroundColor: '#4ECDC4',
      }]} />
      <Animated.View style={[styles.circle, {
        transform: [{ translateX: anim2.interpolate({
          inputRange: [0, 1],
          outputRange: [0, 50],
        }) }],
        backgroundColor: '#4ECDC4',
      }]} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
  },
  circle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    margin: 10,
  },
});