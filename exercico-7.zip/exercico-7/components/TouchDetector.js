import React, { useRef, useState } from 'react';
import { View, PanResponder } from 'react-native';

export default function TouchDetector({ onTouchEvent }) {
  const [touchCount, setTouchCount] = useState(0);
  const holdTimeout = useRef(null);

  const panResponder = PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onPanResponderGrant: (evt) => {
      // Count number of touches
      const count = evt.nativeEvent.touches.length;
      setTouchCount(count);
      
      // Handle hold gesture
      if (count === 1) {
        holdTimeout.current = setTimeout(() => {
          onTouchEvent('hold');
        }, 500);
      }
    },
    onPanResponderRelease: () => {
      // Clear hold timeout
      if (holdTimeout.current) {
        clearTimeout(holdTimeout.current);
        holdTimeout.current = null;
      }
      
      // Handle based on touch count
      if (touchCount === 1) {
        onTouchEvent('single');
      } else if (touchCount === 2) {
        onTouchEvent('double');
      } else if (touchCount === 3) {
        onTouchEvent('triple');
      }
      
      setTouchCount(0);
    },
  });

  return (
    <View 
      style={{ 
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'transparent',
      }}
      {...panResponder.panHandlers}
    />
  );
}