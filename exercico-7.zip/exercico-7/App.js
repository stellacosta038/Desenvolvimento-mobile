import React, { useState } from 'react';
import { View, StyleSheet, Text } from 'react-native';
import TouchDetector from './components/TouchDetector';
import Animation1 from './components/Animation1';
import Animation2 from './components/Animation2';
import Animation3 from './components/Animation3';
import Animation4 from './components/Animation4';

export default function App() {
  const [activeAnimation, setActiveAnimation] = useState(null);

  const handleTouchEvent = (type) => {
    setActiveAnimation(type);
    // Reset animation after 3 seconds
    setTimeout(() => setActiveAnimation(null), 3000);
  };

  return (
    <View style={styles.container}>
      <TouchDetector onTouchEvent={handleTouchEvent} />
      
      {activeAnimation === 'single' && <Animation1 />}
      {activeAnimation === 'double' && <Animation2 />}
      {activeAnimation === 'triple' && <Animation3 />}
      {activeAnimation === 'hold' && <Animation4 />}
      
      {!activeAnimation && (
        <Text style={styles.instructions}>
          Toque na tela: 1 toque, 2 toques, 3 toques ou segure
        </Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  instructions: {
    position: 'absolute',
    bottom: 50,
    fontSize: 18,
    color: '#555',
  },
});