import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';

//TELAS COM SWIPE (TAB NAVIGATION) 
// Módulo 1 - Introdução
function Modulo1Tela1() {
  return (
    <View style={styles.tabContainer}>
      <Text style={styles.tabTitle}>Bem-vindo ao curso!</Text>
      <Text style={styles.tabText}>Este curso irá te ensinar os fundamentos de React Native e navegação entre telas.</Text>
    </View>
  );
}

function Modulo1Tela2() {
  return (
    <View style={styles.tabContainer}>
      <Text style={styles.tabTitle}>Como usar o app</Text>
      <Text style={styles.tabText}>Deslize para os lados para navegar entre as telas de cada módulo.</Text>
      <Text style={styles.tabText}>Use o menu lateral para acessar diferentes seções.</Text>
    </View>
  );
}

function Modulo1Tela3() {
  return (
    <View style={styles.tabContainer}>
      <Text style={styles.tabTitle}>Dicas iniciais</Text>
      <Text style={styles.tabText}>• Pratique regularmente</Text>
      <Text style={styles.tabText}>• Experimente modificar o código</Text>
      <Text style={styles.tabText}>• Consulte a documentação</Text>
    </View>
  );
}

const Modulo1Tab = createMaterialTopTabNavigator();
function Modulo1() {
  return (
    <Modulo1Tab.Navigator>
      <Modulo1Tab.Screen name="Introdução" component={Modulo1Tela1} />
      <Modulo1Tab.Screen name="Como usar" component={Modulo1Tela2} />
      <Modulo1Tab.Screen name="Dicas" component={Modulo1Tela3} />
    </Modulo1Tab.Navigator>
  );
}

// Módulo 2 - Conteúdo
function Modulo2Tela1() {
  return (
    <View style={styles.tabContainer}>
      <Text style={styles.tabTitle}>Capítulo 1 - Conceitos básicos</Text>
      <Text style={styles.tabText}>• Componentes React Native</Text>
      <Text style={styles.tabText}>• Estilos com StyleSheet</Text>
      <Text style={styles.tabText}>• Estado e props</Text>
    </View>
  );
}

function Modulo2Tela2() {
  return (
    <View style={styles.tabContainer}>
      <Text style={styles.tabTitle}>Capítulo 2 - Exemplos práticos</Text>
      <Text style={styles.tabText}>Aqui está um exemplo de código:</Text>
      <Text style={styles.codeText}>const App = () => {"\n"}  return {"<Text>Hello World!</Text>;"}{"\n"}};</Text>
    </View>
  );
}

function Modulo2Tela3() {
  return (
    <View style={styles.tabContainer}>
      <Text style={styles.tabTitle}>Capítulo 3 - Quiz interativo</Text>
      <Text style={styles.tabText}>Qual navegador permite swipe entre telas?</Text>
      <Button title="Stack Navigator" onPress={() => alert('Errado!')} />
      <Button title="Tab Navigator" onPress={() => alert('Correto!')} />
    </View>
  );
}

const Modulo2Tab = createMaterialTopTabNavigator();
function Modulo2() {
  return (
    <Modulo2Tab.Navigator>
      <Modulo2Tab.Screen name="Conceitos" component={Modulo2Tela1} />
      <Modulo2Tab.Screen name="Exemplos" component={Modulo2Tela2} />
      <Modulo2Tab.Screen name="Quiz" component={Modulo2Tela3} />
    </Modulo2Tab.Navigator>
  );
}

// Módulo 3 - Conclusão
function Modulo3Tela1() {
  return (
    <View style={styles.tabContainer}>
      <Text style={styles.tabTitle}>Resumo do curso</Text>
      <Text style={styles.tabText}>• Aprendemos sobre navegação</Text>
      <Text style={styles.tabText}>• Vimos vários exemplos práticos</Text>
      <Text style={styles.tabText}>• Implementamos diferentes navegadores</Text>
    </View>
  );
}

function Modulo3Tela2() {
  return (
    <View style={styles.tabContainer}>
      <Text style={styles.tabTitle}>Próximos passos</Text>
      <Text style={styles.tabText}>1. Aprender sobre estado global</Text>
      <Text style={styles.tabText}>2. Integrar com APIs</Text>
      <Text style={styles.tabText}>3. Publicar seu app</Text>
    </View>
  );
}

function Modulo3Tela3() {
  return (
    <View style={styles.tabContainer}>
      <Text style={styles.tabTitle}>Deixe seu feedback!</Text>
      <Text style={styles.tabText}>O que achou do curso?</Text>
      <Button title="👍 Gostei" onPress={() => alert('Obrigado!')} />
      <Button title="👎 Não gostei" onPress={() => alert('Vamos melhorar!')} />
    </View>
  );
}

const Modulo3Tab = createMaterialTopTabNavigator();
function Modulo3() {
  return (
    <Modulo3Tab.Navigator>
      <Modulo3Tab.Screen name="Resumo" component={Modulo3Tela1} />
      <Modulo3Tab.Screen name="Próximos passos" component={Modulo3Tela2} />
      <Modulo3Tab.Screen name="Feedback" component={Modulo3Tela3} />
    </Modulo3Tab.Navigator>
  );
}

//Navegção (TELAS PRINCIPAIS) 
function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>🏠 Home</Text>
      <Button 
        title="Módulo 1 - Introdução" 
        onPress={() => navigation.navigate('Modulo1')} 
      />
      <Button 
        title="Módulo 2 - Conteúdo" 
        onPress={() => navigation.navigate('Modulo2')} 
      />
      <Button 
        title="Módulo 3 - Conclusão" 
        onPress={() => navigation.navigate('Modulo3')} 
      />
    </View>
  );
}

const HomeStack = createStackNavigator();
function HomeStackScreen() {
  return (
    <HomeStack.Navigator>
      <HomeStack.Screen name="Home" component={HomeScreen} />
      <HomeStack.Screen name="Modulo1" component={Modulo1} options={{ title: 'Módulo 1 - Introdução' }} />
      <HomeStack.Screen name="Modulo2" component={Modulo2} options={{ title: 'Módulo 2 - Conteúdo' }} />
      <HomeStack.Screen name="Modulo3" component={Modulo3} options={{ title: 'Módulo 3 - Conclusão' }} />
    </HomeStack.Navigator>
  );
}

//Navegação (MENU LATERAL)

function ProfileScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>👤 Perfil</Text>
      <View style={styles.profileInfo}>
        <Text style={styles.profileText}>Nome: Stella Gonçalves </Text>
        <Text style={styles.profileText}>Email: stella08@gmail.com</Text>
        <Text style={styles.profileText}>Nível: Intermediário</Text>
      </View>
      <Button title="Editar perfil" onPress={() => alert('Editar perfil')} />
    </View>
  );
}

function SettingsScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>⚙️ Configurações</Text>
      <View style={styles.settingsOption}>
        <Text>Tema: </Text>
        <Button title="Escuro" onPress={() => alert('Tema alterado')} />
        <Button title="Claro" onPress={() => alert('Tema alterado')} />
      </View>
      <View style={styles.settingsOption}>
        <Text>Notificações: </Text>
        <Button title="Ativar" onPress={() => alert('Notificações ativadas')} />
        <Button title="Desativar" onPress={() => alert('Notificações desativadas')} />
      </View>
      <View style={styles.settingsOption}>
        <Text>Idioma: </Text>
        <Button title="Português" onPress={() => alert('Idioma alterado')} />
        <Button title="Inglês" onPress={() => alert('Idioma alterado')} />
      </View>
    </View>
  );
}

const Drawer = createDrawerNavigator();
function App() {
  return (
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="Home">
        <Drawer.Screen name="Home" component={HomeStackScreen} />
        <Drawer.Screen name="Perfil" component={ProfileScreen} />
        <Drawer.Screen name="Configurações" component={SettingsScreen} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}

//Estilos

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  tabContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#fff',
  },
  tabTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  tabText: {
    fontSize: 16,
    marginBottom: 10,
    textAlign: 'center',
  },
  codeText: {
    fontFamily: 'monospace',
    backgroundColor: '#eee',
    padding: 10,
    marginVertical: 10,
  },
  profileInfo: {
    marginBottom: 20,
    padding: 15,
    backgroundColor: '#fff',
    borderRadius: 8,
  },
  profileText: {
    fontSize: 16,
    marginBottom: 8,
  },
  settingsOption: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 15,
    padding: 10,
    backgroundColor: '#fff',
    borderRadius: 8,
  },
});

export default App;