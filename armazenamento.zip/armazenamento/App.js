import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, FlatList, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
import { NavigationContainer } from '@react-navigation/native';

const Tab = createMaterialTopTabNavigator();

const Status = {
  NOVA: 'Nova',
  EM_ANDAMENTO: 'Em andamento',
  CONCLUIDA: 'Concluída'
};

const Prioridade = {
  ALTA: 'Alta',
  NORMAL: 'Normal',
  BAIXA: 'Baixa'
};

const App = () => {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={{
          tabBarLabelStyle: { fontSize: 12, fontWeight: 'bold' },
          tabBarStyle: { backgroundColor: '#6200ee' },
          tabBarActiveTintColor: '#ffffff',
          tabBarIndicatorStyle: { backgroundColor: '#ffeb3b', height: 4 },
        }}
      >
        <Tab.Screen name="Novas" component={() => <TaskScreen status={Status.NOVA} />} />
        <Tab.Screen name="Em Andamento" component={() => <TaskScreen status={Status.EM_ANDAMENTO} />} />
        <Tab.Screen name="Concluídas" component={() => <TaskScreen status={Status.CONCLUIDA} />} />
      </Tab.Navigator>
    </NavigationContainer>
  );
};

const TaskScreen = ({ status }) => {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState('');
  const [priority, setPriority] = useState(Prioridade.NORMAL);
  const [editingTaskId, setEditingTaskId] = useState(null);
  const [editText, setEditText] = useState('');

  useEffect(() => {
    carregarTasks();
  }, []);

  const carregarTasks = async () => {
    const data = await AsyncStorage.getItem('tasks');
    if (data) {
      setTasks(JSON.parse(data));
    }
  };

  const salvarTasks = async (updatedTasks) => {
    await AsyncStorage.setItem('tasks', JSON.stringify(updatedTasks));
    setTasks(updatedTasks);
  };

  const adicionarTask = async () => {
    if (newTask.trim() === '') return;
    
    const newTaskObj = {
      id: Date.now().toString(),
      text: newTask,
      status: status,
      priority: priority,
      createdAt: new Date().toISOString()
    };
    
    const updatedTasks = [...tasks, newTaskObj];
    await salvarTasks(updatedTasks);
    setNewTask('');
    setPriority(Prioridade.NORMAL);
  };

  const excluirTask = async (id) => {
    const updatedTasks = tasks.filter(task => task.id !== id);
    await salvarTasks(updatedTasks);
  };

  const atualizarStatus = async (id, newStatus) => {
    const updatedTasks = tasks.map(task => 
      task.id === id ? { ...task, status: newStatus } : task
    );
    await salvarTasks(updatedTasks);
  };

  const iniciarEdicao = (task) => {
    setEditingTaskId(task.id);
    setEditText(task.text);
  };

  const salvarEdicao = async () => {
    const updatedTasks = tasks.map(task => 
      task.id === editingTaskId ? { ...task, text: editText } : task
    );
    await salvarTasks(updatedTasks);
    setEditingTaskId(null);
    setEditText('');
  };

  const cancelarEdicao = () => {
    setEditingTaskId(null);
    setEditText('');
  };

  const atualizarPrioridade = async (id, newPriority) => {
    const updatedTasks = tasks.map(task => 
      task.id === id ? { ...task, priority: newPriority } : task
    );
    await salvarTasks(updatedTasks);
  };

  const filteredTasks = tasks.filter(task => task.status === status);

  const getPriorityColor = (priority) => {
    switch (priority) {
      case Prioridade.ALTA: return '#ff5252';
      case Prioridade.NORMAL: return '#4caf50';
      case Prioridade.BAIXA: return '#2196f3';
      default: return '#9e9e9e';
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Digite uma nova tarefa"
          value={newTask}
          onChangeText={setNewTask}
        />
        
        <View style={styles.priorityButtons}>
          <TouchableOpacity 
            style={[styles.priorityButton, priority === Prioridade.ALTA && styles.priorityButtonSelectedHigh]}
            onPress={() => setPriority(Prioridade.ALTA)}
          >
            <Text style={styles.priorityButtonText}>Alta</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[styles.priorityButton, priority === Prioridade.NORMAL && styles.priorityButtonSelectedNormal]}
            onPress={() => setPriority(Prioridade.NORMAL)}
          >
            <Text style={styles.priorityButtonText}>Normal</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[styles.priorityButton, priority === Prioridade.BAIXA && styles.priorityButtonSelectedLow]}
            onPress={() => setPriority(Prioridade.BAIXA)}
          >
            <Text style={styles.priorityButtonText}>Baixa</Text>
          </TouchableOpacity>
        </View>
        
        <Button 
          title="Adicionar Tarefa" 
          onPress={adicionarTask} 
          color="#6200ee"
        />
      </View>

      <FlatList
        data={filteredTasks}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={[styles.taskItem, { borderLeftColor: getPriorityColor(item.priority) }]}>
            {editingTaskId === item.id ? (
              <View style={styles.editContainer}>
                <TextInput
                  style={styles.editInput}
                  value={editText}
                  onChangeText={setEditText}
                  autoFocus
                />
                <View style={styles.editButtons}>
                  <Button title="Salvar" onPress={salvarEdicao} color="#4caf50" />
                  <Button title="Cancelar" onPress={cancelarEdicao} color="#f44336" />
                </View>
              </View>
            ) : (
              <>
                <Text style={styles.taskText}>{item.text}</Text>
                <Text style={[styles.priorityText, { color: getPriorityColor(item.priority) }]}>
                  {item.priority}
                </Text>
                <View style={styles.taskButtons}>
                  <Button 
                    title="✏️" 
                    onPress={() => iniciarEdicao(item)} 
                    color="#ff9800"
                  />
                  <Button 
                    title="❌" 
                    onPress={() => excluirTask(item.id)} 
                    color="#f44336"
                  />
                </View>
              </>
            )}
            
            <View style={styles.statusButtons}>
              {status !== Status.NOVA && (
                <Button 
                  title="⬅️ Nova" 
                  onPress={() => atualizarStatus(item.id, Status.NOVA)} 
                />
              )}
              {status !== Status.EM_ANDAMENTO && (
                <Button 
                  title={status === Status.NOVA ? "Andamento ➡️" : "⬅️ Andamento"} 
                  onPress={() => atualizarStatus(item.id, Status.EM_ANDAMENTO)} 
                />
              )}
              {status !== Status.CONCLUIDA && (
                <Button 
                  title="Concluir ✅" 
                  onPress={() => atualizarStatus(item.id, Status.CONCLUIDA)} 
                />
              )}
            </View>
            
            <View style={styles.priorityChangeButtons}>
              <Text style={styles.priorityLabel}>Prioridade:</Text>
              <Button 
                title="⬆️ Alta" 
                onPress={() => atualizarPrioridade(item.id, Prioridade.ALTA)} 
                color={item.priority === Prioridade.ALTA ? '#ff5252' : '#9e9e9e'}
              />
              <Button 
                title="🔼 Normal" 
                onPress={() => atualizarPrioridade(item.id, Prioridade.NORMAL)} 
                color={item.priority === Prioridade.NORMAL ? '#4caf50' : '#9e9e9e'}
              />
              <Button 
                title="⬇️ Baixa" 
                onPress={() => atualizarPrioridade(item.id, Prioridade.BAIXA)} 
                color={item.priority === Prioridade.BAIXA ? '#2196f3' : '#9e9e9e'}
              />
            </View>
          </View>
        )}
        ListEmptyComponent={
          <Text style={styles.emptyListText}>Nenhuma tarefa {status.toLowerCase()} encontrada</Text>
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 15,
    backgroundColor: '#f5f5f5',
  },
  inputContainer: {
    marginBottom: 20,
    backgroundColor: '#ffffff',
    padding: 15,
    borderRadius: 10,
    elevation: 3,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    padding: 12,
    marginBottom: 10,
    borderRadius: 6,
    fontSize: 16,
  },
  priorityButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
  },
  priorityButton: {
    flex: 1,
    padding: 8,
    marginHorizontal: 4,
    borderRadius: 6,
    alignItems: 'center',
    backgroundColor: '#e0e0e0',
  },
  priorityButtonSelectedHigh: {
    backgroundColor: '#ff5252',
  },
  priorityButtonSelectedNormal: {
    backgroundColor: '#4caf50',
  },
  priorityButtonSelectedLow: {
    backgroundColor: '#2196f3',
  },
  priorityButtonText: {
    color: '#ffffff',
    fontWeight: 'bold',
  },
  taskItem: {
    backgroundColor: '#ffffff',
    padding: 15,
    marginBottom: 10,
    borderRadius: 8,
    borderLeftWidth: 6,
    elevation: 2,
  },
  taskText: {
    fontSize: 16,
    marginBottom: 8,
  },
  priorityText: {
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  taskButtons: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginBottom: 10,
  },
  editContainer: {
    marginBottom: 10,
  },
  editInput: {
    borderWidth: 1,
    borderColor: '#ddd',
    padding: 10,
    marginBottom: 10,
    borderRadius: 6,
  },
  editButtons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  statusButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  priorityChangeButtons: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
  },
  priorityLabel: {
    marginRight: 10,
    fontWeight: 'bold',
  },
  emptyListText: {
    textAlign: 'center',
    marginTop: 20,
    fontSize: 16,
    color: '#757575',
  },
});

export default App;