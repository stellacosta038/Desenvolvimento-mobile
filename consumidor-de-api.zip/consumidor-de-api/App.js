import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, FlatList } from 'react-native';
import * as Location from 'expo-location';

const WeatherScreen = () => {
  const [weather, setWeather] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const getWeather = async () => {
    setLoading(true);
    try {
      // Solicita permissão de localização
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setError('Permissão de localização negada. Usando localização padrão (São Paulo).');
        // Fallback: São Paulo
        fetchWeather(-23.5505, -46.6333);
        return;
      }

      // Pega a localização atual
      let location = await Location.getCurrentPositionAsync({});
      const { latitude, longitude } = location.coords;
      fetchWeather(latitude, longitude);
    } catch (error) {
      console.error('Erro ao obter localização:', error);
      setError('Erro ao obter localização. Usando localização padrão.');
      fetchWeather(-23.5505, -46.6333);
    }
  };

  const fetchWeather = async (lat, lon) => {
    try {
      const response = await fetch(
        `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true&hourly=temperature_2m,weathercode&daily=weathercode,temperature_2m_max,temperature_2m_min&timezone=auto`
      );
      const data = await response.json();
      setWeather(data);
      setLoading(false);
    } catch (error) {
      console.error('Erro ao buscar dados da API:', error);
      setError('Erro ao carregar dados meteorológicos.');
      setLoading(false);
    }
  };

  useEffect(() => {
    getWeather();
  }, []);

  const weatherCodeToText = (code) => {
    const map = {
      0: 'Céu limpo ☀️',
      1: 'Principalmente limpo 🌤️',
      2: 'Parcialmente nublado ⛅',
      3: 'Nublado ☁️',
      45: 'Nevoeiro 🌫️',
      48: 'Nevoeiro com gelo 🌫️',
      51: 'Garoa fraca 🌧️',
      61: 'Chuva fraca 🌧️',
      80: 'Pancadas de chuva 🌦️',
      95: 'Tempestade ⛈️',
    };
    return map[code] || 'Tempo indefinido';
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#007AFF" />
        <Text>Carregando previsão do tempo...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.container}>
        <Text style={styles.error}>{error}</Text>
      </View>
    );
  }

  if (!weather) {
    return (
      <View style={styles.container}>
        <Text>Não foi possível carregar os dados meteorológicos.</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Previsão do Tempo</Text>
      
      <View style={styles.currentWeather}>
        <Text style={styles.currentTemp}>{weather.current_weather.temperature}°C</Text>
        <Text style={styles.weatherCondition}>
          {weatherCodeToText(weather.current_weather.weathercode)}
        </Text>
      </View>

      <Text style={styles.subTitle}>Próximas horas:</Text>
      <FlatList
        data={weather.hourly.time.slice(0, 12)}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item, index }) => (
          <View style={styles.hourItem}>
            <Text style={styles.hourText}>{item.slice(11, 16)}h</Text>
            <Text>{weather.hourly.temperature_2m[index]}°C</Text>
          </View>
        )}
        horizontal
        showsHorizontalScrollIndicator={false}
      />

      <Text style={styles.subTitle}>Próximos dias:</Text>
      {weather.daily && (
        <FlatList
          data={weather.daily.time}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({ item, index }) => (
            <View style={styles.dayItem}>
              <Text style={styles.dayText}>
                {new Date(item).toLocaleDateString('pt-BR', { weekday: 'short' })}
              </Text>
              <Text style={styles.dayTemp}>
                {weather.daily.temperature_2m_min[index]}° / {weather.daily.temperature_2m_max[index]}°
              </Text>
              <Text>{weatherCodeToText(weather.daily.weathercode[index])}</Text>
            </View>
          )}
          horizontal
          showsHorizontalScrollIndicator={false}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  currentWeather: {
    alignItems: 'center',
    marginBottom: 20,
  },
  currentTemp: {
    fontSize: 48,
    fontWeight: 'bold',
  },
  weatherCondition: {
    fontSize: 18,
    marginTop: 5,
  },
  subTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginVertical: 10,
  },
  hourItem: {
    padding: 15,
    marginRight: 10,
    backgroundColor: '#fff',
    borderRadius: 10,
    alignItems: 'center',
    elevation: 2,
    minWidth: 70,
  },
  hourText: {
    fontWeight: 'bold',
    marginBottom: 5,
  },
  dayItem: {
    padding: 15,
    marginRight: 10,
    backgroundColor: '#fff',
    borderRadius: 10,
    alignItems: 'center',
    elevation: 2,
    minWidth: 100,
  },
  dayText: {
    fontWeight: 'bold',
    marginBottom: 5,
    textTransform: 'capitalize',
  },
  dayTemp: {
    marginBottom: 5,
  },
  error: {
    color: 'red',
    textAlign: 'center',
    marginTop: 20,
  },
});

export default WeatherScreen;